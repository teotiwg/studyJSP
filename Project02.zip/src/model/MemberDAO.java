package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletContext;


/*
DAO(Data Access Object)
	: 데이터베이스의 Data에 접근하기 위한 객체로 
	DB접근을 위한 로직으로 주로 구성된다. 
	MVC패턴에서는 M(Model)에 해당한다. 
 */
public class MemberDAO {
	
	//멤버변수
	Connection con;//커넥션 객체를 멤버변수로 선언하여 DAO내에서 공유
	Statement stmt;
	PreparedStatement psmt;
	ResultSet rs;
	
	//기본생성자를 통한 오라클 연결
	public MemberDAO() {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://127.0.0.1:3306/kosmo_db";
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url,id,pass);
			System.out.println("MariaDB 연결성공");			 
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new MemberDAO();
	}
	
	public MemberDAO(String driver, String url) {
		try {
			Class.forName(driver);
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url,id,pass);
			System.out.println("MariaDB 연결성공");			 
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public MemberDAO(ServletContext application) {
		try {
			String drv = application.getInitParameter("MariaJDBCDriver");
			String url = application.getInitParameter("MariaConnectURL");
			String id = application.getInitParameter("MariaUser");
			String pwd = application.getInitParameter("MariaPass");
			
			Class.forName(drv);
			//String id = "kosmo";
			//String pass = "1234";
			con = DriverManager.getConnection(url, id, pwd);
			System.out.println("MariaDB 연결성공");			 
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	/*
	 JSP에서 콘텍스트 초기화 파라미터를 읽어서 
	 매개변수로 전달하여 DB연결을 하기 위한 인자생성자 
	 */
	
	public boolean idCheck(String id) {

		String sql = "SELECT COUNT(*) FROM members "
				+ " WHERE id=? ";
		
		int isMember = 0;
		boolean isFlag = false;
		
		try {
			psmt = con.prepareStatement(sql);
			psmt.setString(1,  id);
			rs = psmt.executeQuery();
			
			rs.next();
			isMember = rs.getInt(1);
			
			System.out.println("affected: " + isMember);
			
			if(isMember == 0)
				isFlag = false;
			else
				isFlag = true;
		}
		catch(Exception e) {
			isFlag = false;
			e.printStackTrace();
		}
		System.out.println(isFlag);
		return isFlag;
	}
	
	//그룹함수 count()를 통해 회원의 존재유무만 판단하는 메소드
	public boolean isMember(String id, String pass) {
	 
		//쿼리문 작성
		String sql = "SELECT COUNT(*) FROM members "
				+ " WHERE id=? AND pass=?";
		
		int isMember = 0;
		boolean isFlag = false;

		try {
			//쿼리문을 인수로 prepare객체를 생성한다. 
			psmt = con.prepareStatement(sql);
			//쿼리문의 인파라미터를 설정한다. DB의 인덱스는 1부터 시작함.
			psmt.setString(1, id);
			psmt.setString(2, pass);
			//select쿼리문의 실행결과는 ResultSet객체를 통해 반환받는다.
			rs = psmt.executeQuery();
			//실행결과를 얻어오기 위해 next()를 호출하여 커서를 이동시킨다.
			rs.next();
			//실행결과중 첫번째 값을 얻어오기 위해 getInt()를 사용한다. 
			isMember = rs.getInt(1);
			System.out.println("affected:"+isMember);
			if(isMember==0) //회원이 아닌경우(아이디 패스워드로 회원을 찾을수 없음)
				isFlag = false;
			else //회원인 경우(아이디, 패스워드 일치함)
				isFlag = true; 
		}
		catch(Exception e) {
			//예외가 발생한다면 확인이 불가하므로 무조건 false를 반환한다. 
			isFlag = false;
			e.printStackTrace();
		}
		return isFlag;
	}
	
	/*
	로그인 방법2) 
	쿼리문을 통해 회원인증 후 
	MemberDTO객체에 회원정보를 저장하고 JSP쪽으로 반환해준다 
	 */
	public MemberDTO getMemberDTO(String uid, String upass) {
		
		// 회원정보 저장을 위해 DTO객체 생성
		MemberDTO dto = new MemberDTO();
		
		// 회원정보 조회를 위한 쿼리문 작성
		String query = "SELECT id, pass, name FROM " 
				+ " members WHERE id=? AND pass=?";
		
		try {
			// prepared 객체 생성
			psmt = con.prepareStatement(query);
			// 인파라미터 설정
			psmt.setString(1, uid);
			psmt.setString(2, upass);
			// 쿼리문 실행
			rs = psmt.executeQuery();
			// 오라클이 반환해준 ResultSet객체를 통해 결과값이 있는지 확인
			if(rs.next()) {
				// 결과가 있다면 DTO객체에 회원정보 저장
				dto.setId(rs.getString("id"));
				dto.setPass(rs.getString("pass"));
				dto.setName(rs.getString(3));
			}
			else {
				System.out.println("결과셋이 없습니다.");
			}
		}
		catch(Exception e) {
			System.out.println("getMemberDTO 오류");
			e.printStackTrace();
		}
		return dto;
	}
	
	public Map<String, String> getMemberMap(String uid, String upass){
		
		// 회원정보를 저장할 Map컬렉션 생성
		Map<String, String> maps = new HashMap<String, String>();
		
		String query = "SELECT id, pass, name FROM " 
				+ " members WHERE id=? AND pass=?";
		
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, uid);
			psmt.setString(2, upass);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				maps.put("id", rs.getString(1)); // 아이디
				maps.put("pass", rs.getString(2)); // 비번
				maps.put("name", rs.getString("name")); // 이름
			}
			else {
				System.out.println("결과셋이 없습니다.");
			}
		}
		catch(Exception e) {
			System.out.println("getMemberMap 오류");
			e.printStackTrace();
		}
		// Map컬렉션에 저장된 회원정보 반환
		return maps;
	}
	
	/*
	INSERT INTO members (id, pass, NAME, bday, addr, email, mobile, location) 
	VALUES ('kosmo', '1234', '코스모', '20190101'members, '서울 금천구', 'kosmo@kosmo.com', '010-1234-1234', '서울 금천구');
	*/
	public int newMembers(MemberDTO dto) {
		int result = 0;
		try {
			String query = "INSERT INTO members ( "
					+ " id, pass, NAME, bday, addr, email, mobile) "
					+ " VALUES ( ?, ?, ?, ?, ?, ?, ?)";
			
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPass());
			psmt.setString(3, dto.getName());
			psmt.setString(4, dto.getBday());
			psmt.setString(5, dto.getAddr());
			psmt.setString(6, dto.getEmail());
			psmt.setString(7, dto.getMobile());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("회원가입 중 예외발생");
			e.printStackTrace();
		}
		//System.out.println(result);
		return result;
	}
	
	public String findId(String name, String email, String mobile) {
		System.out.println("1 findID들어옴");
		String id;
		
		MemberDTO dto = new MemberDTO();
		String query = "SELECT id FROM members "
				+ "WHERE name=? AND email=? AND mobile=?";
		
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, name);
			psmt.setString(2, email);
			psmt.setString(3, mobile);
			rs = psmt.executeQuery();

			if(rs.next()) {
				dto.setId(rs.getString(1));
				id = dto.getId();
				System.out.println("if" + id);
			}
			else {
				id = "해당 아이디는 없습니다.";
				System.out.println("else들어옴");
			}
		}
		catch(Exception e) {
			System.out.println("아이디 찾기 중 예외발생");
			e.printStackTrace();
		}
		System.out.println(dto.getId());
		return dto.getId();
	}
	
	public String findPass(String id, String name, String email, String mobile) {
		
		String result;
		MemberDTO dto = new MemberDTO();
		String query = "SELECT pass FROM members "
				+ "WHERE id=? AND name=? AND email=? AND mobile=?";
		
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			psmt.setString(2, name);
			psmt.setString(3, email);
			psmt.setString(4, mobile);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto.setPass(rs.getString(1));
				result = dto.getPass();
			}
			else
				return "해당 아이디는 없습니다.";
		}
		catch(Exception e) {
			System.out.println("비밀번호 찾기 중 예외발생");
			e.printStackTrace();
		}
		result = dto.getPass();
		System.out.println(result);
		return result;
		
	}
	
	public MemberDTO memberView(String id) {
		MemberDTO dto = new MemberDTO();
		
		String query = "SELECT * FROM members "
				+ " WHERE id=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto.setId(rs.getString(1));
				dto.setPass(rs.getString(2));
				dto.setName(rs.getString(3));
				dto.setBday(rs.getString(4));
				dto.setAddr(rs.getString(5));
				dto.setEmail(rs.getString(6));
				dto.setMobile(rs.getString(7));
				dto.setRegidate(rs.getDate(9));
				//dto.setLocation(rs.getString(8));
			}
			
		}
		catch(Exception e) {
			System.out.println("회원정보 조회중 예외발생");
			e.printStackTrace();
		}
		return dto;
	}
	
	public int memberCount(Map<String, Object> map) {
		int totalCount = 0;	
		
		String query = "SELECT COUNT(*) FROM members ";
		//검색 파라미터가 있는 경우라면 where절을 추가한다. 
		if(map.get("searchWord")!=null) {
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") +"%' ";
		}
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			totalCount = rs.getInt(1);
		}
		catch(Exception e) {
			System.out.println("멤버 카운트 중 예외발생");
			e.printStackTrace();
		}

		return totalCount;
	}
	public List<MemberDTO> memberList(Map<String,Object> map){
		
		List<MemberDTO> members = new Vector<MemberDTO>();
	
		String query = "SELECT * FROM members ";
		
		if(map.get("searchWord")!=null){
			query +=" WHERE "+ map.get("searchField") +" "
			  +" LIKE '%"+ map.get("searchWord") +"%' "; 
		}
		query += " ORDER BY regidate DESC ";
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);	
			 
			while(rs.next()) {
				MemberDTO dto = new MemberDTO();

				dto.setId(rs.getString("id"));
				dto.setPass(rs.getString("pass"));
				dto.setName(rs.getString("name"));  
				//dto.setGender(rs.getString("gender"));   
				dto.setBday(rs.getString("bday")); 
				//dto.setZipcode(rs.getString("zipcode"));  
				//dto.setAddress1(rs.getString("address1")); 
				//dto.setAddress2(rs.getString("address2")); 
				dto.setAddr(rs.getString("addr"));
				dto.setEmail(rs.getString("email"));  
				dto.setMobile(rs.getString("mobile"));  
				//dto.setTel(rs.getString("tel"));  
				dto.setRegidate(rs.getDate("regidate"));
				
				members.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("회원 목록 조회(memberList) 중 예외발생");
			e.printStackTrace();
		}
		return members;
	}
	//게시판 목록 출력시 페이지 처리
	public List<MemberDTO> memberListPage(Map<String,Object> map){
		List<MemberDTO> members = new Vector<MemberDTO>();

		String query = " "
				+" SELECT * FROM ( "
				+"	 SELECT Tb.*, ROWNUM rNum FROM ( "
				+"	    SELECT * FROM members ";
		
		if(map.get("searchWord")!=null)
		{
			query +=" WHERE "+ map.get("searchField") +" "
					+" LIKE '%"+ map.get("searchWord") +"%' "; 
		}
		query += " "
				+"    	ORDER BY regidate DESC "
				+"    ) Tb "
				+" ) "
				+" WHERE rNum BETWEEN ? AND ?";
		
		System.out.println("페이지쿼리: " + query);
		try {
			psmt = con.prepareStatement(query);
			//between절의 start와 end값을 인파라미터 설정
			psmt.setString(1, map.get("start").toString());
			psmt.setString(2, map.get("end").toString());
			rs = psmt.executeQuery();
			while(rs.next()) {
				MemberDTO dto = new MemberDTO();
				
				dto.setId(rs.getString("user_id"));
				dto.setPass(rs.getString("pass"));
				dto.setName(rs.getString("name"));  
				//dto.setGender(rs.getString("gender"));   
				dto.setBday(rs.getString("bday")); 
				//dto.setZipcode(rs.getString("zipcode"));  
				//dto.setAddress1(rs.getString("address1")); 
				//dto.setAddress2(rs.getString("address2")); 
				dto.setAddr(rs.getString("addr"));
				dto.setEmail(rs.getString("email"));  
				dto.setMobile(rs.getString("mobile"));  
				//dto.setTel(rs.getString("tel"));  
				dto.setRegidate(rs.getDate("regidate"));
				
				members.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("회원 목록 조회2중 예외발생");
			e.printStackTrace();
		}
		return members;
	}
	public int memberUpdate(MemberDTO dto) {
		System.out.println("들어옴");
		int result = 0;
		try {
			String query = "UPDATE members SET "
				+ " pass=?, name=?, bday=?, "
				//+ " pass=?, name=?, gender=?, birthday=?, "
				//+ " zipcode=?, address1=?, address2=?, "
				//+ " email=?, mobile=?, tel=? "
				+ " addr=?, email=?, mobile=?"
				+ " WHERE id=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getPass());
			psmt.setString(2, dto.getName());
			psmt.setString(3, dto.getBday());
			psmt.setString(4, dto.getAddr());
			psmt.setString(5, dto.getEmail());
			psmt.setString(6, dto.getMobile());
			psmt.setString(7, dto.getId());
			//쿼리문 실행
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("회원정보 수정 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	public int memberDelete(String user_id) {
		int result = 0;
		try {
			String query = "DELETE FROM members WHERE user_id=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, user_id);
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("회원정보 삭제 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public void close() {
		try {
			if(rs != null) rs.close();
			if(psmt != null) psmt.close();
			if(con != null) con.close();
		}
		catch(Exception e) {
			System.out.println("DB 자원 반납 시 예외발생");
		}
	}

}
