package model4.market;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletContext;

public class MarketDAO {
	
	Connection con;
	Statement stmt;
	PreparedStatement psmt;
	ResultSet rs;
	
	public MarketDAO() {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://127.0.0.1:3306/kosmo_db";
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url, id, pass);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public MarketDAO(String driver, String url) {
		try {
			Class.forName(driver);
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url, id, pass);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결 예외발생");
			e.printStackTrace();
		}
	}
	
	public MarketDAO(ServletContext application) {
		try {
			String drv = application.getInitParameter("MariaJDBCDriver");
			String url = application.getInitParameter("MariaConnectURL");
			String id = application.getInitParameter("MariaUser");
			String pwd = application.getInitParameter("MariaPass");
			
			Class.forName(drv);
			con = DriverManager.getConnection(url, id, pwd);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결 예외발생");
			e.printStackTrace();
		}
	}
	public int selectCount(Map<String, Object>map) {
		int totalCount = 0;
		String query = "SELECT COUNT(*) FROM multiboard";
		
		if(map.get("searchWord") != null) {
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") + "%' ";
			
		}
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			totalCount = rs.getInt(1);
		}
		catch(Exception e) {
			System.out.println("게시물 카운트 중 예외발생");
			e.printStackTrace();
		}
		return totalCount;	
	}
	
	public List<MarketDTO> selectList(Map<String, Object>map){
		List<MarketDTO> md = new Vector<MarketDTO>();
		
		String query = "SELECT * FROM multiboard ";
		//String query = "SELECT * FROM multiboard WHERE groups=market ";
		
		if(map.get("searchWord") != null) {
			// WHERE 대신 AND
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") + "%' ";
		}
		query += " ORDER BY num DESC";
		try {
			stmt =con.createStatement();
			rs = stmt.executeQuery(query);
			while(rs.next()) {
				MarketDTO dto = new MarketDTO();
				dto.setNum(rs.getString("num")); 
				dto.setTrade(rs.getString("trade"));
				dto.setTitle(rs.getString("title"));
				//dto.setContent(rs.getString("content"));
				dto.setId(rs.getString("id"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setVisitcount(rs.getString("visitcount"));
				md.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("마켓 게시물 조회 중 예외발생");
			e.printStackTrace();
		}
		return md;
	}
	
	public List<MarketDTO> selectListPage(Map<String, Object>map){
		
		List<MarketDTO> md = new Vector<MarketDTO>();
		
		String query = "SELECT * FROM multiboard WHERE groups='market' ";
		
		if(map.get("searchWord") != null) {
			query += " AND " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") +"%' ";
		}
		
		query += " ORDER BY num DESC LIMIT ?, ?";
			
		System.out.println("페이지쿼리: " + query);
		
		try {
			psmt = con.prepareStatement(query);
			psmt.setInt(1, Integer.parseInt(map.get("start").toString()));
			psmt.setInt(2, Integer.parseInt(map.get("end").toString()));
			rs = psmt.executeQuery();
			while(rs.next()) {
				MarketDTO dto = new MarketDTO();
				
				dto.setNum(rs.getString("num"));
				dto.setTrade(rs.getString("trade"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setId(rs.getString("id"));
				dto.setVisitcount(rs.getString("visitcount"));
				//dto.setGroups(rs.getString("groups"));
				md.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("마켓 게시물 조회 중 예외발생");
			e.printStackTrace();
		}
		return md;	
	}
	
	public int insertWrite(MarketDTO dto) {
		int result = 0;
		try {
			String query = "INSERT INTO multiboard ( "
					+ "trade, title, content, ofile, sfile, id, groups) "
					+ "VALUES ("
					+ "?, ?, ?, ?, ?, ?, ?)";
			
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getTrade());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getContent());
			psmt.setString(4, dto.getOfile());
			psmt.setString(5, dto.getSfile());
			psmt.setString(6, dto.getId());
			psmt.setString(7, dto.getGroups());
			//System.out.println(dto.getId());
			
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("마켓 게시물 입력 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public MarketDTO selectView(String num) {
		MarketDTO dto = new MarketDTO();
		
		String query = "SELECT * FROM multiboard WHERE num=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, num);
			rs= psmt.executeQuery();
			
			if(rs.next()) {
				dto.setNum(rs.getString(1));
				dto.setTrade(rs.getString(2));
				dto.setTitle(rs.getString(3));
				dto.setContent(rs.getString(4));
				dto.setPostdate(rs.getDate(5));
				dto.setOfile(rs.getString(6));
				dto.setSfile(rs.getString(7));
				dto.setDowncount(rs.getInt(8));
				dto.setId(rs.getString(9));
				dto.setVisitcount(rs.getString(10));
			}
			
			/*
			if(rs.next()) {
				dto.setNum(rs.getString(1));
				dto.setTrade(rs.getString(2));
				dto.setTitle(rs.getString(3));
				dto.setContent(rs.getString("content"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setId(rs.getString("id"));
				dto.setVisitcount(rs.getString(6));
			}
			 */	
		}
		catch(Exception e) {
			System.out.println("게시물 상세보기 중 예외발생");
			e.printStackTrace();
		}
		return dto;
	}
	
	public void downCountPlus(String num){
		String sql = "UPDATE multiboard SET "
				+ " downcount=downcount+1 "
				+ " WHERE num=? ";
		try{
			psmt = con.prepareStatement(sql);
			psmt.setString(1, num);
			psmt.executeUpdate();
		}
		catch(Exception e){}
	}
	
	public void updateVisitCount(String num) {
		String query = "UPDATE multiboard SET "
				+ " visitcount=visitcount+1 "
				+ " WHERE num=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, num);
			psmt.executeQuery();
		}
		catch(Exception e) {
			System.out.println("게시물 조회수 증가 중 예외발생");
			e.printStackTrace();
		}
	}
	
	public int updateEdit(MarketDTO dto) {
		int result= 0;
		try {
			String query = "UPDATE multiboard SET "
					+ " trade=?, title=?, content=?, ofile=?, sfile=? "
					+ " WHERE num=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getTrade());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getContent());
			psmt.setString(4, dto.getOfile());
			psmt.setString(5, dto.getSfile());
			psmt.setString(6, dto.getNum());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("게시물 수정 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public int deletePost(MarketDTO dto) {
		int result = 0;
		System.out.println(result);
		try {
			String query = "DELETE FROM multiboard WHERE num=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getNum());
			//psmt.setString(1, dto.getNum());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("게시물 삭제 중 예외발생");
			e.printStackTrace();
		}
		System.out.println(result);
		return result;
	} 
	
	public void close() {
		try {
			if(rs != null) rs.close();
			if(psmt!= null) psmt.close();
			if(con != null) con.close();
		}
		catch(Exception e) {
			System.out.println("자원 반납 중 예외발생");
		}
	}
	
}
