package model5.cats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletContext;

import model.MemberDTO;
import model2.mvcboard.MVCBoardDTO;
import model4.market.MarketDTO;

public class CatsDAO {
	
	Connection con;
	Statement stmt;
	PreparedStatement psmt;
	ResultSet rs;
	
	public CatsDAO() {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://127.0.0.1:3306/kosmo_db";
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url, id, pass);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public static void main(String[] arge) {
		new CatsDAO();
	}
	
	public CatsDAO(String driver, String url) {
		try {
			Class.forName(driver);
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url, id, pass);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public CatsDAO(ServletContext application) {
		try {
			String drv = application.getInitParameter("MariaJDBCDriver");
			String url = application.getInitParameter("MariaConnectURL");
			String id = application.getInitParameter("MariaUser");
			String pwd = application.getInitParameter("MariaPass");
			
			Class.forName(drv);
			con = DriverManager.getConnection(url, id, pwd);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결 예외발생");
			e.printStackTrace();
		}
	}
	
	public boolean isCatMember(String id, String name, String location) {
		 
		String sql = "SELECT COUNT(*) FROM cats "
				+ " WHERE id=? AND name=? and location=?";
		
		int isMember = 0;
		boolean isFlag = false;

		try {
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setString(2, name);
			psmt.setString(3, location);
			rs = psmt.executeQuery();
			rs.next();
			isMember = rs.getInt(1);
			System.out.println("affected:" + isMember);
			if(isMember==0) 
				isFlag = false;
			else 
				isFlag = true; 
		}
		catch(Exception e) {
			isFlag = false;
			e.printStackTrace();
		}
		return isFlag;
	}
	
	
	public CatsDTO getCatsDTO(String id, String name, String location) {
		CatsDTO dto = new CatsDTO();
		
		String query = "SELECT id, name FROM "
				+ " cats WHERE id=? AND name=? and location=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			psmt.setString(2, name);
			psmt.setString(3, location);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setLocation(rs.getString("location"));
			}
			else
				System.out.println("결과셋이 없습니다.");
		}
		catch(Exception e) {
			System.out.println("getCatsDTO 오류");
			e.printStackTrace();
		}
		return dto;
	}
	
	// 게시물 갯수 카운트
	public int selectCount(Map<String, Object>map) {
		int totalCount = 0;
		String query = "SELECT COUNT(*) FROM cats";
		
		if(map.get("searchWord") != null) {
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") + "%' ";		
		}
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			totalCount = rs.getInt(1);
		}
		catch(Exception e) {
			System.out.println("고양이 selectCount 중 예외발생");
			e.printStackTrace();
		}
		return totalCount;	
	}

	public List<CatsDTO> selectList(Map<String, Object>map){
		List<CatsDTO> cl = new Vector<CatsDTO>();
		
		//String query = "SELECT * FROM multiboard ";
		String query = "SELECT * FROM cats";
		
		if(map.get("searchWord") != null) {
			// WHERE 대신 AND
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") + "%' ";
		}
		query += " ORDER BY idx DESC";
		try {
			stmt =con.createStatement();
			rs = stmt.executeQuery(query);
			while(rs.next()) {
				CatsDTO dto = new CatsDTO();
				dto.setId(rs.getString("id"));
				dto.setIdx(rs.getString("idx"));				
				dto.setName(rs.getString("name"));
				dto.setBday(rs.getString("bday"));
				dto.setAddr(rs.getString("addr"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setRegidate(rs.getString("regidate"));
				cl.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("동네 고양이 조회 중 예외발생");
			e.printStackTrace();
		}
		return cl;
	}
	// 목록보기
	public List<CatsDTO> selectListPage(Map<String, Object>map){
		
		List<CatsDTO> pageCats = new Vector<CatsDTO>();
		
		String query = "SELECT * FROM cats ";
		
		if(map.get("searchWord") != null) {
			query += " AND " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") +"%' ";
		}

		query += " ORDER BY idx DESC LIMIT ?, ?";
			
		System.out.println("페이지쿼리: " + query);
		
		try {
			psmt = con.prepareStatement(query);
			psmt.setInt(1, Integer.parseInt(map.get("start").toString()));
			psmt.setInt(2, Integer.parseInt(map.get("end").toString()));
			rs = psmt.executeQuery();
			while(rs.next()) {
				CatsDTO dto = new CatsDTO();
				
				dto.setId(rs.getString("id"));
				dto.setIdx(rs.getString("idx"));				
				dto.setName(rs.getString("name"));
				dto.setBday(rs.getString("bday"));
				dto.setAddr(rs.getString("addr"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setRegidate(rs.getString("regidate"));
				//dto.setGroups(rs.getString("groups"));
				
				pageCats.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("동네 고양이 조회 중 예외발생");
			e.printStackTrace();
		}
		return pageCats;	
	}
	
public List<CatsDTO> selectListPage2(Map<String, Object>map){
		
		List<CatsDTO> pageCats = new Vector<CatsDTO>();
		
		String query = "SELECT * FROM cats ";

		try {
			psmt = con.prepareStatement(query);

			rs = psmt.executeQuery();
			while(rs.next()) {
				CatsDTO dto = new CatsDTO();
				
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setBday(rs.getString("Bday"));
				dto.setAddr(rs.getString("addr"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setRegidate(rs.getString("regidate"));
				dto.setGroups(rs.getString("groups"));
			}
		}
		catch(Exception e) {
			System.out.println("동네 고양이 사진 조회 중 예외발생");
			e.printStackTrace();
		}
		return pageCats;	
	}
	
	public int insertWrite(CatsDTO dto) {
		int result = 0;
		try {
			String query = "INSERT INTO cats ( "
				+ " id, name, bday, addr, ofile, sfile) "
				+ " VALUES ( "
				+ " ?, ?, ?, ?, ?, ?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getName());
			psmt.setString(3, dto.getBday());
			psmt.setString(4, dto.getAddr());
			psmt.setString(5, dto.getOfile());
			psmt.setString(6, dto.getSfile());
			//psmt.setString(6, dto.getPass());
			//psmt.setString(7, dto.getGroups());
			result = psmt.executeUpdate();
		} 
		catch(Exception e) {
			System.out.println("게시물 입력중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public CatsDTO selectView(String idx) {
		System.out.println(idx);
		CatsDTO dto = new CatsDTO();
		System.out.println("1");
		String query = "SELECT * FROM cats WHERE idx=? ";
		/*
		String query = "SELECT C.*, M.name "
				+ " FROM members M INNER JOIN cats C "
				+ " ON M.id=C.id "
				+ " WHERE idx=?";
		*/
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, idx);
			rs= psmt.executeQuery();
			System.out.println("2");
			if(rs.next()) {
				dto.setIdx(rs.getString("idx"));
				dto.setName(rs.getString("name"));
				dto.setRegidate(rs.getString("regidate"));
				dto.setId(rs.getString("founder"));
				dto.setAddr(rs.getString("addr"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setRef(rs.getString("contents"));
				//dto.setBday(rs.getString("bday"));
				//dto.setLocation(rs.getString("location"));
				//dto.setFounder(rs.getString("founder"));
				//dto.setManagers(rs.getString("managers"));
				//dto.setFans(rs.getString("fans"));
				//dto.setHospital(rs.getString("hospital"));
				//dto.setSnacks(rs.getString("snacks"));
				//dto.setPass(rs.getString("pass"));
			}
		}
		catch(Exception e) {
			System.out.println("고양이 게시물 상세보기 중 예외발생");
			e.printStackTrace();
		}
		System.out.println(dto.getIdx());
		System.out.println(dto.getName());
		return dto;
	}
	
	public void downCountPlus(String id){
		String sql = "UPDATE cats SET "
				+ " downcount=downcount+1 "
				+ " WHERE id=? ";
		try{
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.executeUpdate();
		}
		catch(Exception e){}
	}
	/*
	public void updateVisitCount(String id) {
		String query = "UPDATE cats SET "
				+ " visitcount=visitcount+1 "
				+ " WHERE id=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			psmt.executeQuery();
		}
		catch(Exception e) {
			System.out.println("고양이 게시물 조회수 증가 중 예외발생");
			e.printStackTrace();
		}
	}
	*/
	public int updateEdit(CatsDTO dto) {
		int result= 0;
		try {
			String query = "UPDATE cats SET "
					+ " title=?, content=?, ofile=?, sfile=? "
					+ " WHERE id=?";
			psmt = con.prepareStatement(query);
			//psmt.setString(1, dto.getTitle());
			//psmt.setString(2, dto.getContent());
			//psmt.setString(3, dto.getOfile());
			//psmt.setString(4, dto.getSfile());
			//psmt.setString(3, dto.getPass());
			//psmt.setString(5, dto.getNum());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("고양이 게시물 수정 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean confirmPassword(String pass, String id) {
		boolean isCorr = true;
		try {
			// 일련번호와 패스워드가 일치하는 게시물이 있는지 확인
			String sql = "SELECT COUNT(*) FROM cats WHERE pass=? AND idx=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, pass);
			psmt.setString(2, id);
			rs = psmt.executeQuery();
			rs.next();
			if(rs.getInt(1) == 0) {
				// 패스워드가 일치하는 게시물이없으므로 false
				isCorr = false;
			}
		}
		catch(Exception e) {
			// 예외가 발생하여 확인이 불가하므로 false
			isCorr = false;
			e.printStackTrace();
		}
		return isCorr;
	}
	
	public int deletePost(String id) {
		int result = 0;
		System.out.println(result);
		try {
			String query = "DELETE FROM cats WHERE idx=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, id);
			//psmt.setString(1, dto.getNum());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("게시물 삭제 중 예외발생");
			e.printStackTrace();
		}
		System.out.println(result);
		return result;
	} 
	
	public void close() {
		try {
			if(rs != null) rs.close();
			if(psmt != null) psmt.close();
			if(con != null) con.close();
		}
		catch(Exception e) {
			System.out.println("자원반납 중 예외발생");
		}
	}
}
