package model3.catsboard;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletContext;

import model.MemberDTO;
import model2.mvcboard.MVCBoardDTO;
import model4.market.MarketDTO;

public class CatBoardDAO {
	
	Connection con;
	Statement stmt;
	PreparedStatement psmt;
	ResultSet rs;
	
	public CatBoardDAO() {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://127.0.0.1:3306/kosmo_db";
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url, id, pass);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public static void main(String[] arge) {
		new CatBoardDAO();
	}
	
	public CatBoardDAO(String driver, String url) {
		try {
			Class.forName(driver);
			String id = "kosmo_user";
			String pass = "1234";
			con = DriverManager.getConnection(url, id, pass);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결시 예외발생");
			e.printStackTrace();
		}
	}
	
	public CatBoardDAO(ServletContext application) {
		try {
			String drv = application.getInitParameter("MariaJDBCDriver");
			String url = application.getInitParameter("MariaConnectURL");
			String id = application.getInitParameter("MariaUser");
			String pwd = application.getInitParameter("MariaPass");
			
			Class.forName(drv);
			con = DriverManager.getConnection(url, id, pwd);
			System.out.println("MariaDB 연결 성공");
		}
		catch(Exception e) {
			System.out.println("MariaDB 연결 예외발생");
			e.printStackTrace();
		}
	}
	/*
	public boolean isCatMember(String id, String name, String location) {
		 
		String sql = "SELECT COUNT(*) FROM multiboard "
				+ " WHERE id=? AND name=?";
		
		int isMember = 0;
		boolean isFlag = false;

		try {
			psmt = con.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setString(2, name);
			rs = psmt.executeQuery();
			rs.next();
			isMember = rs.getInt(1);
			System.out.println("affected:" + isMember);
			if(isMember==0) 
				isFlag = false;
			else 
				isFlag = true; 
		}
		catch(Exception e) {
			isFlag = false;
			e.printStackTrace();
		}
		return isFlag;
	}
	*/
	/*
	public CatBoardDTO getCatsDTO(String uid, String upass) {
		CatBoardDTO dto = new CatBoardDTO();
		
		String query = "SELECT id, name FROM "
				+ " multiboard WHERE id=? AND pass=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, uid);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				//dto.setLocation(rs.getString("location"));
			}
			else
				System.out.println("결과셋이 없습니다.");
		}
		catch(Exception e) {
			System.out.println("getCatsDTO 오류");
			e.printStackTrace();
		}
		return dto;
	}
	*/
	// 게시물 갯수 카운트
	public int selectCount(Map<String, Object>map) {
		int totalCount = 0;
		String query = "SELECT COUNT(*) FROM multiboard";
		
		if(map.get("searchWord") != null) {
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") + "%' ";		
		}
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			totalCount = rs.getInt(1);
		}
		catch(Exception e) {
			System.out.println("고양이 selectCount 중 예외발생");
			e.printStackTrace();
		}
		return totalCount;	
	}

	public List<CatBoardDTO> selectList(Map<String, Object>map){
		List<CatBoardDTO> md = new Vector<CatBoardDTO>();
		
		//String query = "SELECT * FROM multiboard ";
		String query = "SELECT * FROM multiboard WHERE groups=catPost";
		
		if(map.get("searchWord") != null) {
			// WHERE 대신 AND
			query += " WHERE " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") + "%' ";
		}
		query += " ORDER BY num DESC";
		try {
			stmt =con.createStatement();
			rs = stmt.executeQuery(query);
			while(rs.next()) {
				CatBoardDTO dto = new CatBoardDTO();
				dto.setNum(rs.getString("num")); 
				dto.setId(rs.getString("id"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				//dto.setName(rs.getString("name"));
				//dto.setBirthday(rs.getString("birthday"));
				//dto.setAddr(rs.getString("addr"));
				//dto.setId(rs.getString("id"));
				//dto.setRegidate(rs.getDate("regidate"));
				dto.setPostdate(rs.getString("postdate"));
				dto.setVisitcount(rs.getString("visitcount"));
				md.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("동네 고양이 조회 중 예외발생");
			e.printStackTrace();
		}
		return md;
	}
	// 목록보기
	public List<CatBoardDTO> selectListPage(Map<String, Object>map){
		
		List<CatBoardDTO> pageCats = new Vector<CatBoardDTO>();
		
		String query = "SELECT * FROM multiboard WHERE groups='catPost' ";
		
		if(map.get("searchWord") != null) {
			query += " AND " + map.get("searchField") + " "
					+ " LIKE '%" + map.get("searchWord") +"%' ";
		}

		query += " ORDER BY num DESC LIMIT ?, ?";
			
		System.out.println("페이지쿼리: " + query);
		
		try {
			psmt = con.prepareStatement(query);
			psmt.setInt(1, Integer.parseInt(map.get("start").toString()));
			psmt.setInt(2, Integer.parseInt(map.get("end").toString()));
			rs = psmt.executeQuery();
			while(rs.next()) {
				CatBoardDTO dto = new CatBoardDTO();
				
				dto.setNum(rs.getString("num"));
				dto.setId(rs.getString("id"));
				//dto.setName(rs.getString("name"));
				//dto.setLocation(rs.getString("location"));
				dto.setTitle(rs.getString("title"));
				//dto.setContent(rs.getString("contents"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setPostdate(rs.getString("postdate"));
				dto.setVisitcount(rs.getString("visitcount"));
				dto.setGroups(rs.getString("groups"));
				System.out.println(rs.getString("groups"));
				
				pageCats.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("동네 고양이 조회 중 예외발생");
			e.printStackTrace();
		}
		return pageCats;	
	}
	
public List<CatBoardDTO> selectListPage2(Map<String, Object>map){
		
		List<CatBoardDTO> pageCats = new Vector<CatBoardDTO>();
		
		String query = "SELECT * FROM multiboard WHERE groups='catPost' ";

		try {
			psmt = con.prepareStatement(query);

			rs = psmt.executeQuery();
			while(rs.next()) {
				CatBoardDTO dto = new CatBoardDTO();
				
				dto.setNum(rs.getString("num"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setPostdate(rs.getString("postdate"));
				dto.setVisitcount(rs.getString("visitcount"));
				dto.setGroups(rs.getString("groups"));
				pageCats.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("동네 고양이 사진 조회 중 예외발생");
			e.printStackTrace();
		}
		return pageCats;	
	}
	
	public int insertWrite(CatBoardDTO dto) {
		int result = 0;
		try {
			String query = "INSERT INTO multiboard ( "
				+ " id, title, content, ofile, sfile, groups) "
				+ " VALUES ( "
				+ " ?, ?, ?, ?, ?, ?)";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getContent());
			psmt.setString(4, dto.getOfile());
			psmt.setString(5, dto.getSfile());
			//psmt.setString(6, dto.getPass());
			psmt.setString(6, dto.getGroups());
			result = psmt.executeUpdate();
		} 
		catch(Exception e) {
			System.out.println("게시물 입력중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public CatBoardDTO selectView(String num) {
		CatBoardDTO dto = new CatBoardDTO();
		
		String query = "SELECT * FROM multiboard WHERE num=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, num);
			rs= psmt.executeQuery();
			
			if(rs.next()) {
				dto.setNum(rs.getString("num"));
				dto.setId(rs.getString("id"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setPostdate(rs.getString("postdate"));
				dto.setOfile(rs.getString("ofile"));
				dto.setSfile(rs.getString("sfile"));
				dto.setDowncount(rs.getString("downcount"));
				dto.setPass(rs.getString("pass"));
				dto.setVisitcount(rs.getString("visitcount"));
			}
			/*
			if(rs.next()) {
				dto.setNum(rs.getString(1));
				dto.setId(rs.getString(2));
				dto.setTitle(rs.getString(3));
				dto.setContent(rs.getString(4));
				dto.setPostdate(rs.getString(5));
				dto.setOfile(rs.getString(6));
				dto.setSfile(rs.getString(7));
				dto.setDowncount(rs.getString(8));
				dto.setPass(rs.getString(9));
				dto.setVisitcount(rs.getString(10));
			}*/
	
		}
		catch(Exception e) {
			System.out.println("고양이 게시물 상세보기 중 예외발생");
			e.printStackTrace();
		}
		return dto;
	}
	
	public void downCountPlus(String num){
		String sql = "UPDATE multiboard SET "
				+ " downcount=downcount+1 "
				+ " WHERE num=? ";
		try{
			psmt = con.prepareStatement(sql);
			psmt.setString(1, num);
			psmt.executeUpdate();
		}
		catch(Exception e){}
	}
	
	public void updateVisitCount(String num) {
		String query = "UPDATE multiboard SET "
				+ " visitcount=visitcount+1 "
				+ " WHERE num=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, num);
			psmt.executeQuery();
		}
		catch(Exception e) {
			System.out.println("고양이 게시물 조회수 증가 중 예외발생");
			e.printStackTrace();
		}
	}
	
	public int updateEdit(CatBoardDTO dto) {
		int result= 0;
		try {
			String query = "UPDATE multiboard SET "
					+ " title=?, content=?, ofile=?, sfile=? "
					+ " WHERE num=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getTitle());
			psmt.setString(2, dto.getContent());
			psmt.setString(3, dto.getOfile());
			psmt.setString(4, dto.getSfile());
			//psmt.setString(3, dto.getPass());
			psmt.setString(5, dto.getNum());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("고양이 게시물 수정 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean confirmPassword(String pass, String num) {
		boolean isCorr = true;
		try {
			// 일련번호와 패스워드가 일치하는 게시물이 있는지 확인
			String sql = "SELECT COUNT(*) FROM multiboard WHERE pass=? AND num=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, pass);
			psmt.setString(2, num);
			rs = psmt.executeQuery();
			rs.next();
			if(rs.getInt(1) == 0) {
				// 패스워드가 일치하는 게시물이없으므로 false
				isCorr = false;
			}
		}
		catch(Exception e) {
			// 예외가 발생하여 확인이 불가하므로 false
			isCorr = false;
			e.printStackTrace();
		}
		return isCorr;
	}
	
	public int deletePost(String num) {
		int result = 0;
		System.out.println(result);
		try {
			String query = "DELETE FROM multiboard WHERE num=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1, num);
			//psmt.setString(1, dto.getNum());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("게시물 삭제 중 예외발생");
			e.printStackTrace();
		}
		System.out.println(result);
		return result;
	} 
	
	public void close() {
		try {
			if(rs != null) rs.close();
			if(psmt != null) psmt.close();
			if(con != null) con.close();
		}
		catch(Exception e) {
			System.out.println("자원반납 중 예외발생");
		}
	}
}
