package model3.catsboard;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model2.mvcboard.CommentDAO;
import model2.mvcboard.CommentDTO;

@WebServlet("/catboard/view.do")
public class ViewController extends HttpServlet {
	/*
	서블릿의 수명주기 메소드 중 사용자의 요청을 받아서
	get 혹은 post를 판단하여 분기하는 역할
	따라서 두가지 요청 모두 받을 수 있음 
	 */
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String num = req.getParameter("num");
		CatBoardDAO dao = new CatBoardDAO();
		dao.updateVisitCount(num); // 조회수 증가
		CatBoardDTO dto = dao.selectView(num); // 게시물 조회
		req.setAttribute("dto", dto);
		dao.close();
		
		// 내용에 대해서는 줄바꿈 처리/ 엔터키를 <br>로 변경
 		dto.setContent(dto.getContent().replaceAll("\r\n", "<br/>"));
		req.setAttribute("dto", dto);
		
		// 댓글목록 기능 추가
		CommentDAO dao2 = new CommentDAO();
		// 현재 조회하는 게시물의 일련번호를 통해 댓글목록을 가져옴
		List<CommentDTO> comments = dao2.commentSelectList(num);
		req.setAttribute("comments", comments);
		dao2.close();
		
		req.getRequestDispatcher("/BoardCats/View.jsp").forward(req,resp);
	
	}
	
}
