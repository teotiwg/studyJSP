package model3.catsboard;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;

import fileupload.FileUtil;
import utils.JSFunction;

@WebServlet("/catboard/edit.do")
public class EditController extends HttpServlet {
	
	// 수정폼
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		// 파라미터로 전달된 일련번호를 통해 기존 게시물 조회
		String num = req.getParameter("num");
		CatBoardDAO dao = new CatBoardDAO();
		CatBoardDTO dto = dao.selectView(num);
		
		// 하나의 레코드를 저장한 DTO객체를 request영역에 저장한 후 View로 포워드
		req.setAttribute("dto", dto);
		req.getRequestDispatcher("/BoardCats/Edit.jsp").forward(req, resp);
		
	}
	
	// 수정 처리
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		// 물리적 경로와 제한용량을 통해 MultipartRequest 객체생성 및 파일 업로드
		String saveDirectory = req.getServletContext().getRealPath("/Uploads");
		ServletContext application = this.getServletContext();
		int maxPostSize = Integer.parseInt(application.getInitParameter("maxPostSize"));
		MultipartRequest mr = FileUtil.uploadFile(req, saveDirectory, maxPostSize);
		if(mr != null) {
			// 파일 제외한 나머지 폼값 받기
			String num = mr.getParameter("num");
			String id = mr.getParameter("id");
			String title = mr.getParameter("title");
			String content = mr.getParameter("content");
			
			String prevOfile = mr.getParameter("prevOfile");
			String prevSfile = mr.getParameter("prevSfile");
			
			
			/*
			서블릿에서 getSession()메소드를 통해 session내장객체를 얻어온 후
			session영역의 비밀번호를 가져와 DTO에 저장
			 */
			HttpSession session = req.getSession();
			//String pass = (String)session.getAttribute("pass");
			
			CatBoardDTO dto = new CatBoardDTO();
			dto.setNum(num);
			dto.setId(id);
			dto.setTitle(title);
			dto.setContent(content);
			//dto.setPass(pass);
			
			// 새롭게 업로드된 파일의 이름을 얻어옴
			String fileName = mr.getFilesystemName("ofile");
			if(fileName != null) {
				// 새롭게 등록된 파일이 있다면 파일명 변경을 위해 파일명을 결정
				String nowTime = new SimpleDateFormat("yyyyMMdd_HmsS").format(new Date());
				int extIdx = fileName.lastIndexOf(".");
				String newFileName = nowTime + fileName.substring(extIdx, fileName.length());
				
				// 저장된 파일의 파일명을 변경
				File oldFile =new File(saveDirectory + File.separator + fileName);
				File newFile =new File(saveDirectory + File.separator + newFileName);
				oldFile.renameTo(newFile);
				
				// 새로운 파일명을 DTO에 저장
				dto.setOfile(fileName);
				dto.setSfile(newFileName);
				
				// 기존에 등록된 파일 삭제
				FileUtil.deleteFile(req, "/Uploads", prevSfile);
				
			}
			else { 
				/*
				새롭게 등록된 파일이 없다면 기존파일명을 유지하기 위해
				hidden입력상자의 내용을 그대로 적용 
				 */
				dto.setOfile(prevOfile);
				dto.setSfile(prevSfile);
			}
			
			// 레코드 업데이트 처리
			CatBoardDAO dao = new CatBoardDAO();
			int result = dao.updateEdit(dto);
			dao.close();
			if(result == 1) {
				//session.removeAttribute("pass");
				resp.sendRedirect("../catboard/view.do?num=" + num);
			}
			else {
				//JSFunction.alertLocation(resp, "비밀번호 검증을 다시 해주세요.", "../catboard/view.do?num="+num);
				JSFunction.alertBack(resp, "EditController 오류 발생");
			}
		}
		else {
			/*
			디렉토리의 물리적 경로가 잘못됐거나, 파일용량이 초과됐을 때에는 
			MultipartRequest객체가 생성되지 않음
			즉 글쓰기 오류 발생 
			*/
			JSFunction.alertBack(resp, "글 수정 중 오류 발생");
		}
	}
}
