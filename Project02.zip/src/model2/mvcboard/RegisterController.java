package model2.mvcboard;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

import com.oreilly.servlet.MultipartRequest;

import fileupload.FileUtil;
import model.MemberDAO;
import model.MemberDTO;

public class RegisterController extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/Project02/WebContent/06Session/RegiForm.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ServletContext mr = getServletContext();
		ServletContext application = this.getServletContext();
		
		String id = mr.getInitParameter("user_id");
		String pw = mr.getInitParameter("pass1");
		String name = mr.getInitParameter("name");
		String bday = mr.getInitParameter("birthday");
		String address = mr.getInitParameter("address1" + "address2");
		String email = mr.getInitParameter("email1" + "@" + "email2");
		String mobile = mr.getInitParameter("mobile1" + "mobile2" + "mobile3");

		//web.xml의 컨텍스트 초기화 파라미터 읽어옴
		String drv = application.getInitParameter("MariaJDBCDriver");
		String url = application.getInitParameter("MariaConnectURL");

		MemberDTO dto = new MemberDTO();
		dto.setId(id);
		dto.setPass(pw);
		dto.setName(name);
		dto.setBday(bday);
		dto.setAddr(address);
		dto.setEmail(email);
		dto.setMobile(mobile);

		MemberDAO dao = new MemberDAO();
		dao.newMembers(dto);
		dao.close();
		//resp.sendRedirect("");
	}

}
