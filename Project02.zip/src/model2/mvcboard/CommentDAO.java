package model2.mvcboard;

import java.util.List;
import java.util.Vector;

import common.ConnectionPool;

public class CommentDAO extends ConnectionPool{
	
	public CommentDAO() {
		super();
	}
	
	public int commentInsert(CommentDTO dto) {
		int result = 0;
		try {
			String query ="INSERT INTO comments ( "
					+ " idx, board_idx, id ,pass, comments) "
					+ " VALUES ( "
					+ " ?, ?, ?, ?, ?) ";
			
			psmt = con.prepareStatement(query);			
			psmt.setString(1, dto.getIdx());
			psmt.setString(2, dto.getBoard_idx());
			psmt.setString(3, dto.getId());
			psmt.setString(4, dto.getPass());
			psmt.setString(5, dto.getComments());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("댓글 입력 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	// MVCBoard의 일련번호를 매개변수로 받아 해당 댓글을 조회하는 메소드
	public List<CommentDTO> commentSelectList(String board_idx){
		List<CommentDTO> comments = new Vector<CommentDTO>();
		
		// 댓글 작성일으르 시:분까지 출력하기 위해 to_char()함수 사용
		String query = "SELECT idx, board_idx, id, pass, comments, "
				+ " date_format(postdate, '%Y-%m-%d %H:%i') "
				+ " FROM comments "
				+ " WHERE board_idx=? "
				+ " ORDER BY idx DESC";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1,  board_idx);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				CommentDTO dto = new CommentDTO();
				dto.setIdx(rs.getString(1));
				dto.setBoard_idx(rs.getString(2));
				dto.setId(rs.getString(3));
				dto.setPass(rs.getString(4));
				dto.setComments(rs.getString(5).replaceAll("\r\n", "<br/>"));
				//dto.setCommentsEdit(rs.getString(5));
				dto.setPostdate(rs.getString(6));
				
				comments.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("댓글 조회 중 예외발생");
			e.printStackTrace();
		}
		return comments;
	}
	
	public CommentDTO commentSelectView(CommentDTO dto) {
		
		String query = "SELECT * FROM comments "
				+ " WHERE idx=? and board_idx=? ";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getIdx());
			psmt.setString(2, dto.getBoard_idx());
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto.setIdx(rs.getString(1));
				dto.setBoard_idx(rs.getString(2));
				dto.setId(rs.getString(3));
				dto.setPass(rs.getString(4));
				dto.setComments(rs.getString(5));
				dto.setPostdate(rs.getString(6));
			}
		}
		catch(Exception e) {
			System.out.println("댓글 조회 중 예외발생");
			e.printStackTrace();
		}
		return dto;
	}
	
	public int commentUpdate(CommentDTO dto) {
		int result = 0;
		try {
			String query = "UPDATE comments SET "
					+ " id=?, comments=? "
					+ " WHERE idx=? AND board_idx=? AND pass=?";
			
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getComments());
			psmt.setString(3, dto.getIdx() );
			psmt.setString(4, dto.getBoard_idx());
			psmt.setString(5, dto.getPass());
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("댓글 수정 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
	
	public int commentDelete(String idx) {
		int result = 0;
		try {
			String query = " DELETE FROM comments WHERE idx=?";
			psmt = con.prepareStatement(query);
			psmt.setString(1,  idx);
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("댓글 삭제 중 예외발생");
			e.printStackTrace();
		}
		return result;
	}
}
